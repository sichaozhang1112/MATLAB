% helix
z = 151 : 180;
theta = linspace(-3*pi,3*pi,30);
x = 10*cos(theta);
y = 10*sin(theta);
s = [x;y;z];

% plot3(x,y,z)

