To see the report
sz53_pw15_Project/Report

To see the video
sz53_pw15_Project/Video

To execute the code
sz53_pw15_Project/Code
1. kinematics
wirte in MATLAB commande window:
draw3D('helix.mat')

2. dynamics
wirte in MATLAB commande window:
DrawTorques('helix.mat')

3. path generation
run the code:
DrawMazeSol.m

wirte in MATLAB commande window:
draw3D_3('maze_sol.mat')
but this procedure will be really slow and take much of the RAM.




