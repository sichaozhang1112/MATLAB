Our dataset for problem 5:

"drawsomething.mat": this dataset is a rising curve. It is draw in 4 different colors.
		     When observing from the top, it is a shape of heart.